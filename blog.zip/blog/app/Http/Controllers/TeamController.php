<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use View;
use App\Team;
use App\Country;
use App\Schedule;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Session;
use Redirect;

class TeamController extends Controller {
   
    public function __construct() {
      //$this->middleware('auth');
    }
	/**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        // get all the Team
        $teams = Team::all();
		
		$teamsCountry = Country::all();

        // load the view and pass the teams
        return View::make('teams.index')
            ->with('teams', $teams)->with('country',$teamsCountry);
    
    }
	/**
     * Show the form for creating a new resource.
     *
     * @return Response
    */
    public function create()
    {
        return View::make('teams.create');
    }
	
	public function store()
	{
			// validate
        // read more on validation at http://laravel.com/docs/validation
        $rules = array(
            'name'       => 'required',
            'country'      => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);

        // process the login
        if ($validator->fails()) {
            return Redirect::to('teams/create')
                ->withErrors($validator)
                ->withInput(Input::except('password'));
        } else {
            // store
            $team = new Team();
            $team->name       = Input::get('name');
            $team->country    = Input::get('country');
            $team->save();
            // redirect
            Session::flash('message', 'Successfully player added!');
            return Redirect::to('teams');
        }
    
	}
	public function teammatch()
	{
		$teamgroup = Input::get('teamsgroup');
		$mname = Input::get('mname');
		
		$totalteam = count($teamgroup);
		
		$matchDate = strtotime("2 days"); //Match is schedule after two days
		
		
		if($totalteam !=2)   //altest two team is needed to sehedule the game 
		{
			Session::flash('message', 'Atleast two team required');
			return Redirect::to('teams');
		}
		
		if($totalteam < 3)
		{
			$schedule = new Schedule();
			$schedule->match_name = $mname;
			$schedule->country_id1 = $teamgroup[0];
			$schedule->country_id2 = $teamgroup[1];
			$schedule->match_date = date('Y-m-d',$matchDate);
			$schedule->save();
		}
		
		Session::flash('message', 'Successfully match scheduled!');
		return Redirect::to('teams');
		
	}
	public function play()
	{
		$scheduleData = Schedule::all();
		
		return View::make('teams.play')
            ->with('schedule', $scheduleData);
	}	
}