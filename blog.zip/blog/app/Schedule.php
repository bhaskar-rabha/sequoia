<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Schedule extends Model
{
    
	public function country1()
	{
		return $this->belongsTo(Country::class, 'country_id1');		
	}
	public function country2()
	{
		return $this->belongsTo(Country::class, 'country_id2');		
	}
}
