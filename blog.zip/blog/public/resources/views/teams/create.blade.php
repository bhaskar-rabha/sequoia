<!-- app/views/nerds/create.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Teams: ADD</title>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">

<nav class="navbar navbar-inverse">
    <div class="navbar-header">
        <a class="navbar-brand" href="{{ URL::to('teams') }}">Team Alert</a>
    </div>
    <ul class="nav navbar-nav">
        <li><a href="{{ URL::to('teams') }}">View All Player</a></li>
        <li><a href="{{ URL::to('teams/create') }}">Create a Player</a>
    </ul>
</nav>

<h1>Create a Team</h1>

<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}

{{ Form::open(array('url' => 'teams')) }}

    <div class="form-group">
        {{ Form::label('name', 'Player Name') }}
        {{ Form::text('name', Input::old('name'), array('class' => 'form-control')) }}
    </div>

    <div class="form-group">
        {{ Form::label('country', 'Country') }}
        {{ Form::select('country', array('0' => 'Select a country', 'india' => 'India', 'pakistan' => 'pakistan', 'turkey' => 'Turkey'), Input::old('country'), array('class' => 'form-control')) }}
    </div>

    

    {{ Form::submit('Create the Player!', array('class' => 'btn btn-primary')) }}

{{ Form::close() }}

</div>
</body>
</html>