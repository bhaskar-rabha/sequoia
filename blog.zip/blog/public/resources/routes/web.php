<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
 //   return view('welcome');
//});
Route::get('/', 'TeamController@index')->name('teams.index');

Route::get('teams', 'TeamController@index')->name('teams.index');
Route::get('teams/create', 'TeamController@create')->name('teams.create');

Route::post('teams', 'TeamController@store')->name('teams.store');

Route::get('/teams/{id}/show', 'TeamController@show')->name('teams.show');

Route::get('/teams/{id}/edit', 'TeamController@edit')->name('teams.edit');

Route::post('/teams/teammatch', 'TeamController@teammatch')->name('teams.teammatch');

Route::get('/teams/play', 'TeamController@play')->name('teams.play');