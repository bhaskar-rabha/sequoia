<!DOCTYPE html>
<html>
<head>
    <title>Teams</title>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
	<body>
		<div class="container">
			<nav class="navbar navbar-inverse">
				<div class="navbar-header">
					<a class="navbar-brand" href="<?php echo e(URL::to('teams')); ?>">Teams Alert</a>
				</div>
				<ul class="nav navbar-nav">
					<li><a href="<?php echo e(URL::to('teams')); ?>">View All Teams</a></li>
					<li><a href="<?php echo e(URL::to('teams/create')); ?>">Create a Team</a></li>
					<li><a href="<?php echo e(URL::to('teams/play')); ?>">Play</a></li>
				</ul>
				</nav>

				<h1>All the Teams</h1>

				<!-- will be used to show any messages -->
				<?php if(Session::has('message')): ?>
				<div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
				<?php endif; ?>
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<td>#</td>
						<td>Team 1</td>
						<td>Team 2</td>
						<td>Schedule Date</td>
						<td>Actions</td>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td>#</td>
						<td><?php echo e($value->country1->name); ?></td>
						<td><?php echo e($value->country2->name); ?></td>
						<td><?php echo e($value->match_date); ?></td>
						<td><a class="btn btn-small btn-info" href="<?php echo e(URL::to('teams/' . $value->id . '/edit')); ?>">Play</a></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

		</div>
	</body>
</html>