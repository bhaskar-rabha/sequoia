<!-- app/views/nerds/create.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Teams: ADD</title>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">

<nav class="navbar navbar-inverse">
    <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo e(URL::to('teams')); ?>">Team Alert</a>
    </div>
    <ul class="nav navbar-nav">
        <li><a href="<?php echo e(URL::to('teams')); ?>">View All Player</a></li>
        <li><a href="<?php echo e(URL::to('teams/create')); ?>">Create a Player</a>
    </ul>
</nav>

<h1>Create a Team</h1>

<!-- if there are creation errors, they will show here -->
<?php echo e(HTML::ul($errors->all())); ?>


<?php echo e(Form::open(array('url' => 'teams'))); ?>


    <div class="form-group">
        <?php echo e(Form::label('name', 'Player Name')); ?>

        <?php echo e(Form::text('name', Input::old('name'), array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('country', 'Country')); ?>

        <?php echo e(Form::select('country', array('0' => 'Select a country', 'india' => 'India', 'pakistan' => 'pakistan', 'turkey' => 'Turkey'), Input::old('country'), array('class' => 'form-control'))); ?>

    </div>

    

    <?php echo e(Form::submit('Create the Player!', array('class' => 'btn btn-primary'))); ?>


<?php echo e(Form::close()); ?>


</div>
</body>
</html>